const express = require("express");
const app = express();
const PORT = process.env.PORT || 3000;

// Body parser middleware
app.use(express.json());

// Simple API route example
app.get("/", (req, res) => {
    res.send("Welcome to the Mini Forum!");
});

// Starting the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

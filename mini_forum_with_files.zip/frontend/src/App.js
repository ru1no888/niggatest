import React from "react";

function App() {
    return (
        <div>
            <h1>Welcome to the Mini Forum!</h1>
            <p>This is your homepage for the forum.</p>
        </div>
    );
}

export default App;
